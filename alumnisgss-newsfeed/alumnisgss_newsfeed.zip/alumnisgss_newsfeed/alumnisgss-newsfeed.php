<?php
   /*
   Plugin Name: Alumni SGSS newsfeed
   Plugin URI: N/A
   description: A plugin to temporary put posts in newsfeed
   Version: 1.1
   Author: L. Zampieri
   License: MIT
   */

require( __DIR__ . '/setup.php');
require( __DIR__ . '/edit.php');
require( __DIR__ . '/blocks/load_blocks.php');