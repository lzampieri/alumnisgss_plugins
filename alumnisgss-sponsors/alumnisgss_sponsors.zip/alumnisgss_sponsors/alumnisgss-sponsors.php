<?php
   /*
   Plugin Name: Alumni SGSS sponsors
   Plugin URI: N/A
   description: A plugin to add a nice sponsors gallery
   Version: 1.1
   Author: L. Zampieri
   License: MIT
   */

require( __DIR__ . '/setup.php');
require( __DIR__ . '/edit.php');
require( __DIR__ . '/blocks/load_blocks.php');