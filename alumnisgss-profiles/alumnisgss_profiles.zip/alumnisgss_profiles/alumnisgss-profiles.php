<?php
   /*
   Plugin Name: Alumni SGSS profiles
   Plugin URI: N/A
   description: A plugin to present CdA members with cards and bios. Works only with AlumniSGSS theme.
   Version: 1.0
   Author: L. Zampieri
   License: MIT
   */

require( __DIR__ . '/setup.php');
require( __DIR__ . '/edit.php');
require( __DIR__ . '/blocks/load_blocks.php');